"""Shared style for the A1 poster figures.

Every figure is drawn at (close to) its printed size on the poster, so the
font sizes below are the real point sizes on paper. Poster body text is
24.5pt; figure text should not go below ~17pt.
"""
from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

MM = 1 / 25.4  # millimetres -> inches

# Printed widths on the poster (mm)
WIDTH_HALF = 262   # each half of section 1
WIDTH_SEC2 = 205   # section 2 (40% column)
WIDTH_SEC3 = 310   # section 3 (60% column)

# ---------------------------------------------------------------------
# Names: same as the paper
# ---------------------------------------------------------------------
ZEPHYR = "Zephyr"
L2 = "Llama 3 (Llama 2 recipe)"
MIXAT = "Llama 3 (MixAT recipe)"
CONFIGS = [ZEPHYR, L2, MIXAT]

COLORS = {ZEPHYR: "#1f77b4", L2: "#ff7f0e", MIXAT: "#2ca02c"}
MARKERS = {ZEPHYR: "o", L2: "s", MIXAT: "^"}

# Good / bad direction (colour-blind safe: blue vs vermillion)
GOOD = "#0072B2"
BAD = "#D55E00"
NEUTRAL = "0.35"

# ---------------------------------------------------------------------
# Sizes (points)
# ---------------------------------------------------------------------
FS_TICK = 17
FS_LABEL = 19
FS_TITLE = 20
FS_ANNOT = 17
LW = 2.6
MS = 9
ELW = 1.8
CAPSIZE = 4


def apply():
    plt.rcParams.update({
        "font.family": "sans-serif",
        "font.sans-serif": ["Helvetica", "Arial", "Nimbus Sans",
                            "Liberation Sans", "DejaVu Sans"],
        "mathtext.fontset": "dejavusans",
        "font.size": FS_LABEL,
        "axes.titlesize": FS_TITLE,
        "axes.titleweight": "bold",
        "axes.labelsize": FS_LABEL,
        "xtick.labelsize": FS_TICK,
        "ytick.labelsize": FS_TICK,
        "legend.fontsize": FS_LABEL,
        "axes.linewidth": 1.4,
        "xtick.major.width": 1.4,
        "ytick.major.width": 1.4,
        "xtick.major.size": 6,
        "ytick.major.size": 6,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
    })


def style_axes(ax):
    ax.grid(alpha=0.3, linewidth=1.0)
    ax.set_axisbelow(True)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)


def save(fig, name):
    out = Path(__file__).resolve().parent / "poster_figs"
    out.mkdir(exist_ok=True)
    fig.savefig(out / f"{name}.pdf", bbox_inches="tight", pad_inches=0.05)
    fig.savefig(out / f"{name}.png", dpi=200, bbox_inches="tight", pad_inches=0.05)
    print(f"Saved: {out / name}.pdf")


def config_handles():
    return [Line2D([0], [0], color=COLORS[c], marker=MARKERS[c], linewidth=LW,
                   markersize=MS + 2, label=c) for c in CONFIGS]
