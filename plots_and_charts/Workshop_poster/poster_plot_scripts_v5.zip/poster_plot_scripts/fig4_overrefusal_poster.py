"""Poster version of the OR-Bench dumbbell figure (section 3).

Changes vs the paper figure (data unchanged, loaded from or_n1000_data.py):
- rows ordered as the story: OR-Bench (target) -> Harmless -> Soft-Prompt ASR
- arrow and Delta coloured by effect: blue = better, vermillion = worse
  (direction-aware: higher is better for OR-Bench/Harmless, lower for ASR)
- baseline +/- 1 SD error bars ON (3 seeds); replacement SD shown where available
- neutral markers (grey circle = baseline, black diamond = with OR data),
  so colour only encodes better/worse
- epsilon rounded to 3 decimals in titles; drawn at printed size
"""
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.lines import Line2D

import poster_style as ps
from or_n1000_data import models

ps.apply()

PANELS = [  # (key in or_n1000_data, display name, radius index)
    ("Zephyr", "Zephyr", 2),
    ("Zephyr", "Zephyr", 3),
    ("Llama 3 (MixAT)", "Llama 3 (MixAT recipe)", 2),
    ("Llama 3 (MixAT)", "Llama 3 (MixAT recipe)", 3),
]

# (data key, row label, higher_is_better)
ROWS = [
    ("OR held-out", "Held-out\nOR-Bench ↑", True),
    ("Harmless", "Harmless ↑", True),
    ("Soft-Prompt", "Soft-Prompt\nASR ↓", False),
]
ROW_Y = {"OR held-out": 2.6, "Harmless": 1.45, "Soft-Prompt": 0.0}
SEPARATOR_Y = 0.78

BASE_C = "0.55"
REP_C = "0.05"
MIN_ARROW = 1.5


def panel(ax, key, idx, show_ylabels):
    d = models[key]
    for metric, _, higher_better in ROWS:
        y = ROW_Y[metric]
        base = d[metric]["baseline"]["y"][idx]
        base_err = d[metric]["baseline"]["err"][idx]
        rep = d[metric]["replacement"]["y"][idx]
        rep_err = d[metric]["replacement"]["err"][idx]
        delta = rep - base
        better = (delta > 0) == higher_better
        col = ps.GOOD if better else ps.BAD

        if abs(delta) >= MIN_ARROW:
            ax.annotate("", xy=(rep, y), xytext=(base, y), zorder=2,
                        arrowprops=dict(arrowstyle="-|>", color=col, linewidth=3.0,
                                        shrinkA=7, shrinkB=9, mutation_scale=20))
        if not np.isnan(base_err) and base_err > 0:
            ax.errorbar(base, y, xerr=base_err, fmt="none", color=BASE_C,
                        capsize=5, linewidth=2.0, zorder=1)
        if not np.isnan(rep_err) and rep_err > 0:
            ax.errorbar(rep, y, xerr=rep_err, fmt="none", color=REP_C,
                        capsize=5, linewidth=1.6, alpha=0.6, zorder=1)
        ax.scatter(base, y, marker="o", s=170, color=BASE_C, edgecolor="white",
                   linewidth=1.0, zorder=3)
        ax.scatter(rep, y, marker="D", s=140, color=REP_C, edgecolor="white",
                   linewidth=1.0, zorder=4)
        ax.text(np.clip((base + rep) / 2, 24, 80), y + 0.24, rf"$\Delta$ {delta:+.1f}",
                ha="center", va="bottom", fontsize=ps.FS_ANNOT, color=col,
                fontweight="bold")

    ax.axhline(SEPARATOR_Y, color="0.5", linestyle="-.", linewidth=1.4)
    ax.set_xlim(-5, 107)
    ax.set_ylim(-0.4, 3.25)
    ax.set_yticks([ROW_Y[m] for m, _, _ in ROWS])
    ax.set_yticklabels([lab for _, lab, _ in ROWS])
    if not show_ylabels:
        ax.tick_params(axis="y", labelleft=False, length=0)
    ax.set_xticks([0, 50, 100])
    ax.grid(axis="x", linestyle="--", alpha=0.35)
    ax.set_axisbelow(True)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)


fig, axes = plt.subplots(1, len(PANELS), figsize=(ps.WIDTH_SEC3 * ps.MM, 119 * ps.MM),
                         sharey=True)
for i, (ax, (key, label, idx)) in enumerate(zip(axes, PANELS)):
    panel(ax, key, idx, show_ylabels=(i == 0))
    eps = models[key]["epsilon"][idx]
    ax.set_title(f"{label}\n" + rf"$\epsilon = {eps:.3f}$", fontsize=ps.FS_TICK)

fig.supxlabel("Score / ASR (%)", fontsize=ps.FS_LABEL, x=0.58, y=0.01)
handles = [
    Line2D([0], [0], marker="o", linestyle="none", markerfacecolor=BASE_C,
           markeredgecolor="white", markersize=14, label="Baseline (3 seeds ± s.d.)"),
    Line2D([0], [0], marker="D", linestyle="none", markerfacecolor=REP_C,
           markeredgecolor="white", markersize=12, label="With 1,000 OR examples (mostly 1 seed)"),
    Line2D([0], [0], color=ps.GOOD, linewidth=3, label="better"),
    Line2D([0], [0], color=ps.BAD, linewidth=3, label="worse"),
]
fig.legend(handles=handles, frameon=False, loc="upper center", ncol=4,
           bbox_to_anchor=(0.55, 1.0), fontsize=ps.FS_TICK, handletextpad=0.4,
           columnspacing=0.9)
fig.subplots_adjust(left=0.135, right=0.995, bottom=0.18, top=0.72, wspace=0.08)
ps.save(fig, "fig4_overrefusal")
