"""Poster version of the utility figure (section 1b).

Changes vs the paper figure (data unchanged):
- only panels (a) MMLU and (b) Harmless; the dominance panels (c, d) stay in the paper
- drawn at printed size with poster fonts; no legend (shared legend in section 1)
- titles say which kind of utility each panel measures
- epsilon = 0 (unmodified model) drawn as hollow markers
"""
import matplotlib.pyplot as plt
import numpy as np

import poster_style as ps

ps.apply()

# ---------------------------------------------------------------------
# Data (copied unchanged from the paper script)
# ---------------------------------------------------------------------
models = {
    ps.ZEPHYR: {
        "epsilon": np.array([0.0, 0.00884, 0.01768, 0.03535, 0.07070]),
        "Harmless": {"y": np.array([100, 98.33, 94.17, 89.17, 70.83]),
                     "err": np.array([0.0, 1.44, 3.82, 1.44, 9.46])},
        "MMLU": {"y": np.array([56.02, 55.05, 54.98, 55.17, 54.92]),
                 "err": np.array([0.0, 0.30, 0.26, 0.17, 0.17])},
    },
    ps.L2: {
        "epsilon": np.array([0.0, 0.02949, 0.04424, 0.05898, 0.08848,
                             0.11797, 0.17695, 0.23594, 0.35391]),
        "Harmless": {"y": np.array([100, 95.83, 90.83, 76.67, 45.83, 49.17, 7.50, 2.50, 1.67]),
                     "err": np.array([0.0, 1.44, 7.22, 7.64, 26.96, 20.05, 12.99, 4.33, 2.89])},
        "MMLU": {"y": np.array([60.75, 60.10, 59.74, 59.83, 59.35, 58.81, 57.69, 56.23, 54.94]),
                 "err": np.array([0.0, 0.09, 0.17, 0.13, 0.55, 0.11, 0.45, 1.04, 0.98])},
    },
    ps.MIXAT: {
        "epsilon": np.array([0.0, 0.04424, 0.08848, 0.17695, 0.35391]),
        "Harmless": {"y": np.array([100.0, 82.50, 58.33, 20.83, 50.00]),
                     "err": np.array([0.0, 13.92, 14.65, 15.07, 41.61])},
        "MMLU": {"y": np.array([60.75, 59.73, 59.47, 58.51, 55.74]),
                 "err": np.array([0.0, 0.22, 0.14, 0.68, 0.41])},
    },
}


def panel(ax, metric, title, ylabel, ylim):
    for name, d in models.items():
        eps, y, err = d["epsilon"], d[metric]["y"], d[metric]["err"]
        c, m = ps.COLORS[name], ps.MARKERS[name]
        ax.plot(eps, y, color=c, linewidth=ps.LW, zorder=2)
        ax.errorbar(eps[1:], y[1:], yerr=err[1:], fmt=m, color=c, markersize=ps.MS,
                    elinewidth=ps.ELW, capsize=ps.CAPSIZE, zorder=3)
        ax.plot(eps[0], y[0], m, markersize=ps.MS + 1, markerfacecolor="white",
                markeredgecolor=c, markeredgewidth=2.2, zorder=4, clip_on=False)
    ax.set_xlim(-0.012, 0.37)
    ax.set_ylim(*ylim)
    ax.set_xticks([0, 0.1, 0.2, 0.3])
    ax.set_xlabel(r"Configured radius $\epsilon$")
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    ps.style_axes(ax)


fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(ps.WIDTH_HALF * ps.MM, 105 * ps.MM))
panel(ax1, "MMLU", "Capability", "MMLU accuracy (%)  ↑", (53.5, 61.5))
panel(ax2, "Harmless", "Benign compliance", "Harmless answered (%)  ↑", (-3, 103))
fig.tight_layout(w_pad=2.0)
ps.save(fig, "fig2_utility")
