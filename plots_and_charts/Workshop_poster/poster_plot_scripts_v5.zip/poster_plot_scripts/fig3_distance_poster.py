"""Poster version of the neighbour-distance figure (section 2, paper Fig. 3b only).

Changes vs the paper figure (data unchanged):
- single panel: realized perturbation D vs distance to the nearest other token
- the utilization panel (a) stays in the paper
- direct labels on the lines instead of two legends; config colours come
  from the shared legend in section 1
- names match the paper ("Llama 3 (Llama 2 recipe)", "Llama 3 (MixAT recipe)")
"""
import matplotlib.pyplot as plt
import numpy as np

import poster_style as ps

ps.apply()

# ---------------------------------------------------------------------
# Data (copied unchanged from the paper script)
# Columns: epsilon, D mean, D std, Rank-2 mean, Rank-2 std, Changed mean, Changed std
# ---------------------------------------------------------------------
data = {
    ps.ZEPHYR: np.array([
        [0.00884, 0.00734, 0.00003, 0.13535, 0.00001, 0.00000, 0.00000],
        [0.01768, 0.01466, 0.00006, 0.13574, 0.00006, 0.00000, 0.00000],
        [0.03535, 0.02688, 0.00068, 0.13710, 0.00017, 0.00000, 0.00000],
        [0.07070, 0.04422, 0.00423, 0.14057, 0.00067, 0.00000, 0.00000],
    ]),
    ps.L2: np.array([
        [0.02949, 0.02492, 0.00050, 0.36474, 0.00022, 0.00000, 0.00000],
        [0.04424, 0.03491, 0.00107, 0.36621, 0.00027, 0.00000, 0.00000],
        [0.05898, 0.04517, 0.00030, 0.36817, 0.00001, 0.00000, 0.00000],
        [0.08848, 0.06035, 0.00039, 0.37127, 0.00028, 0.00000, 0.00000],
        [0.11797, 0.07039, 0.00285, 0.37407, 0.00093, 0.00004, 0.00005],
        [0.17695, 0.09350, 0.00361, 0.38030, 0.00063, 0.00100, 0.00000],
        [0.23594, 0.10172, 0.00553, 0.38384, 0.00141, 0.00300, 0.00200],
        [0.35391, 0.13176, 0.00496, 0.39605, 0.00196, 0.01000, 0.00200],
    ]),
    ps.MIXAT: np.array([
        [0.04424, 0.03539, 0.00045, 0.36637, 0.00017, 0.00000, 0.00000],
        [0.08848, 0.05884, 0.00232, 0.37101, 0.00080, 0.00000, 0.00000],
        [0.17695, 0.09078, 0.00334, 0.37950, 0.00068, 0.00100, 0.00100],
        [0.35391, 0.13500, 0.00616, 0.39738, 0.00174, 0.00900, 0.00100],
    ]),
}

fig, ax = plt.subplots(figsize=(ps.WIDTH_SEC2 * ps.MM, 120 * ps.MM))

for name, v in data.items():
    eps, D, D_sd, r2, r2_sd = v[:, 0], v[:, 1], v[:, 2], v[:, 3], v[:, 4]
    c, m = ps.COLORS[name], ps.MARKERS[name]
    ax.errorbar(eps, D, yerr=D_sd, color=c, marker=m, linestyle="-", linewidth=ps.LW,
                markersize=ps.MS, elinewidth=ps.ELW, capsize=ps.CAPSIZE, zorder=3)
    ax.errorbar(eps, r2, yerr=r2_sd, color=c, marker=m, linestyle="--", linewidth=ps.LW,
                markersize=ps.MS, markerfacecolor="white", markeredgewidth=2.0,
                elinewidth=ps.ELW, capsize=ps.CAPSIZE, zorder=3)

# Direct labels instead of legends
ax.text(0.20, 0.41, "Nearest other token (Llama 3)", fontsize=ps.FS_ANNOT,
        color=ps.NEUTRAL, ha="center", va="bottom")
ax.text(0.085, 0.152, "Nearest other token\n(Zephyr)", fontsize=ps.FS_ANNOT,
        color=ps.NEUTRAL, ha="left", va="bottom", linespacing=1.0)
ax.text(0.30, 0.075, r"Realized perturbation $D$", fontsize=ps.FS_ANNOT,
        color=ps.NEUTRAL, ha="center", va="top")

ax.set_xlim(0, 0.37)
ax.set_ylim(0, 0.45)
ax.set_xticks([0, 0.1, 0.2, 0.3])
ax.set_xlabel(r"Configured radius $\epsilon$")
ax.set_ylabel("Distance in embedding space")
ax.set_title("Perturbations stay near their own token")
ps.style_axes(ax)
fig.tight_layout()
ps.save(fig, "fig3_distance")
