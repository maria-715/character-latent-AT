"""Shared configuration legend, placed once at the top of section 1."""
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

import poster_style as ps

ps.apply()
fig = plt.figure(figsize=(540 * ps.MM, 14 * ps.MM))
handles = ps.config_handles() + [
    Line2D([0], [0], marker="o", linestyle="none", markerfacecolor="white",
           markeredgecolor="0.3", markeredgewidth=2.2, markersize=ps.MS + 2,
           label=r"$\epsilon=0$: unmodified model"),
]
fig.legend(handles=handles, loc="center", ncol=4, frameon=False,
           fontsize=ps.FS_LABEL, columnspacing=2.2, handlelength=2.6)
ps.save(fig, "legend_configs")
