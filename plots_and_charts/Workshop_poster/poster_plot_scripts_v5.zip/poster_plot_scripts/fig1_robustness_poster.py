"""Poster version of the robustness figure (section 1a).

Changes vs the paper figure (data unchanged):
- drawn at printed size with poster fonts, thicker lines
- short titles; no legend (one shared legend sits at the top of section 1)
- broken GCG axis replaced by a clipped axis + label for Zephyr's 92.5%
- epsilon = 0 (unmodified model) drawn as hollow markers
"""
import matplotlib.pyplot as plt
import numpy as np

import poster_style as ps

ps.apply()

# ---------------------------------------------------------------------
# Data (copied unchanged from the paper script)
# ---------------------------------------------------------------------
models = {
    ps.ZEPHYR: {
        "epsilon": np.array([0.0, 0.00884, 0.01768, 0.03535, 0.07070]),
        "GCG": {"y": np.array([92.5, 19.17, 17.50, 18.33, 9.17]),
                "err": np.array([0.0, 3.82, 6.61, 10.10, 1.44])},
        "Soft-Prompt": {"y": np.array([74.09, 43.44, 43.40, 42.45, 51.13]),
                        "err": np.array([0.0, 4.53, 5.42, 13.65, 3.21])},
    },
    ps.L2: {
        "epsilon": np.array([0.0, 0.02949, 0.04424, 0.05898, 0.08848,
                             0.11797, 0.17695, 0.23594, 0.35391]),
        "GCG": {"y": np.array([28.33, 22.50, 20.83, 16.67, 22.50, 19.17, 19.17, 22.50, 33.33]),
                "err": np.array([0.0, 6.61, 3.82, 10.41, 12.99, 7.22, 11.55, 5.00, 9.46])},
        "Soft-Prompt": {"y": np.array([75.41, 52.62, 57.29, 48.32, 59.25, 51.26, 59.33, 62.53, 64.46]),
                        "err": np.array([0.0, 2.55, 9.37, 1.89, 16.08, 3.17, 1.41, 5.64, 2.30])},
    },
    ps.MIXAT: {
        "epsilon": np.array([0.0, 0.04424, 0.08848, 0.17695, 0.35391]),
        "GCG": {"y": np.array([28.33, 25.83, 12.50, 17.50, 25.00]),
                "err": np.array([0.0, 1.44, 2.50, 6.61, 10.90])},
        "Soft-Prompt": {"y": np.array([75.41, 55.47, 43.23, 58.18, 63.21]),
                        "err": np.array([0.0, 4.46, 3.92, 4.86, 3.20])},
    },
}

GCG_YMAX = 47  # clip; Zephyr's unmodified model (92.5%) is labelled instead


def panel(ax, metric, title, ylim):
    for name, d in models.items():
        eps, y, err = d["epsilon"], d[metric]["y"], d[metric]["err"]
        c, m = ps.COLORS[name], ps.MARKERS[name]
        y_plot = np.minimum(y, ylim[1])
        ax.plot(eps, y_plot, color=c, linewidth=ps.LW, zorder=2, clip_on=False)
        ax.errorbar(eps[1:], y[1:], yerr=err[1:], fmt=m, color=c, markersize=ps.MS,
                    elinewidth=ps.ELW, capsize=ps.CAPSIZE, zorder=3)
        # unmodified model (epsilon = 0): hollow marker
        ax.plot(eps[0], y_plot[0], m, markersize=ps.MS + 1, markerfacecolor="white",
                markeredgecolor=c, markeredgewidth=2.2, zorder=4, clip_on=False)
    ax.set_xlim(-0.012, 0.37)
    ax.set_ylim(*ylim)
    ax.set_xticks([0, 0.1, 0.2, 0.3])
    ax.set_xlabel(r"Configured radius $\epsilon$")
    ax.set_ylabel("ASR (%)  ↓")
    ax.set_title(title)
    ps.style_axes(ax)


fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(ps.WIDTH_HALF * ps.MM, 105 * ps.MM))
panel(ax1, "GCG", "GCG", (0, GCG_YMAX))
panel(ax2, "Soft-Prompt", "Soft-Prompts", (25, 80))

# Zephyr's unmodified model is off the GCG scale
ax1.annotate("92.5", xy=(0, GCG_YMAX), xytext=(0.025, GCG_YMAX - 4),
             fontsize=ps.FS_ANNOT, color=ps.COLORS[ps.ZEPHYR], va="center",
             arrowprops=dict(arrowstyle="->", color=ps.COLORS[ps.ZEPHYR], lw=1.8))

fig.tight_layout(w_pad=2.0)
ps.save(fig, "fig1_robustness")
